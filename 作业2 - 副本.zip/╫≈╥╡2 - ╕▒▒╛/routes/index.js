var express = require('express');
var router = express.Router();
var db = require('./db/db');
/* GET home page. */
router.get('/', function(req, res, next) {
  db.sql("select * from student",(err,rows) => {
    console.log(err);
    console.log(rows);
  })
  res.render('index');
});

module.exports = router;